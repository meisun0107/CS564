SELECT COUNT(*) 
FROM USER 
WHERE Location == 'New York';